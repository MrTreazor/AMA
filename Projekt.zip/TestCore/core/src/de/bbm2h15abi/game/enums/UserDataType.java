package de.bbm2h15abi.game.enums;

/**
 * Created by osboxes on 6/20/17.
 */
public enum UserDataType {

    GROUND,
    RUNNER,
    ENEMY
}
