package de.bbm2h15abi.game.box2d;

import de.bbm2h15abi.game.enums.UserDataType;

/**
 * Created by osboxes on 6/20/17.
 */
public class GroundUserData extends UserData {

    public GroundUserData(float width, float height){
        super(width, height);
        userDataType = UserDataType.GROUND;
    }
}
