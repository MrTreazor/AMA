package de.bbm2h15abi.game.box2d;

import com.badlogic.gdx.math.Vector2;
import de.bbm2h15abi.game.enums.UserDataType;
import de.bbm2h15abi.game.utils.Constants;

/**
 * Created by osboxes on 6/24/17.
 */
public class EnemyUserData extends UserData{

    private Vector2 linearVelocity;

    public EnemyUserData(float width, float height){
        super(width, height);
        userDataType = UserDataType.ENEMY;
        linearVelocity = Constants.ENEMY_LINEAR_VELOCITY;
    }

    public void setLinearVelocity(Vector2 linearVelocity){

        this.linearVelocity = linearVelocity;
    }

    public Vector2 getLinearVelocity(){
        return linearVelocity;
    }
}
