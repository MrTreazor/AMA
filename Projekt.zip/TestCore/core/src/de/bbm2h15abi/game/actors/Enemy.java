package de.bbm2h15abi.game.actors;

import com.badlogic.gdx.physics.box2d.Body;
import de.bbm2h15abi.game.box2d.EnemyUserData;

/**
 * Created by osboxes on 6/24/17.
 */
public class Enemy extends GameActor{

    public Enemy(Body body){
        super(body);
    }

    @Override
    public EnemyUserData getUserData(){
        return (EnemyUserData) userData;
    }

    @Override
    public void act(float delta){
        super.act(delta);
        body.setLinearVelocity(getUserData().getLinearVelocity());
    }
}
