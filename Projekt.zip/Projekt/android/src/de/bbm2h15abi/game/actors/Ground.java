package de.bbm2h15abi.game.actors;

import com.badlogic.gdx.physics.box2d.Body;
import de.bbm2h15abi.game.box2d.GroundUserData;

/**
 * Created by osboxes on 6/20/17.
 */
public class Ground extends GameActor {

    public Ground(Body body){
        super(body);
    }

    @Override
    public GroundUserData getUserData(){

        return (GroundUserData) userData;
    }


}
