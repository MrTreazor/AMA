package de.bbm2h15abi.game;


import com.badlogic.gdx.Game;

/**
 * Created by osboxes on 6/13/17.
 */
public class Mährechärcher extends Game{
    @Override
    public void create(){
        setScreen(new GamesCream());
    }


}
